Hello Friend <br>

<div>
    Message: <?php echo e($data); ?>

</div><?php /**PATH C:\Users\Dario\Desktop\Webclosure\laravel\resources\views/email/test.blade.php ENDPATH**/ ?>