<!DOCTYPE html>
<html>
<head>
    <title>AllPHPTricks.com</title>
</head>
<body>
    <h1><?php echo e($testMailData['title']); ?></h1>
    <p><?php echo e($testMailData['body']); ?></p>
</body>
</html><?php /**PATH C:\Users\Dario\Desktop\Webclosure\laravel\resources\views/emails/demoMail.blade.php ENDPATH**/ ?>