<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Order;
use App\Models\Billing;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\LaravelTenTestMail;

class OrderController extends Controller
{

    public function getAll() {
        return DB::table('orders')
        ->join('billing','orders.order_id','billing.orderId')
        ->join('products','orders.product_id','products.id')
        ->get();
    }

    public function statusChange(Request $request) {
        $email = $request->get('email');
        $status = $request->get('status');
        $state = "";
        if($request->get('status') == "COMPLETE") {
            $state = "Consegnato";
        }
        if($request->get('status') == "IN PROGRESS") {
            $state = "Preso in carico";
        }
        if($request->get('status') == "SHIPPING") {
            $state = "In consegna";
        }

        $data = [
            'data' => '#274635',
            'status' => '#274635',
            'subject' => 'Aggiornamento della consegna',
            'view' => 'statusChange'
        ];


        $orders = Order::where("order_id", $request->get("id"))->get();
        foreach($orders as $order) {
            $order->status = $request->get("status");
            $order->save();
        }
        
        Mail::to($email)->send(
            new LaravelTenTestMail($data)
        );
        
    }

    public function checkoutEmail($email, $cart) {
        $data = [
            'data' => '#274635',
            'subject' => 'Nuovo ordine',
            'view' => 'checkout'
        ];
        Mail::to($email)->send(
            new LaravelTenTestMail($data)
        );
    }
    public function checkout(Request $request) {
        
        $stripe = new \Stripe\StripeClient('sk_test_51NGgNzGfXypnSGPSkdMqKlzm59UbUjgC7i0KsfIW0YmpuYjEly1EI0mm0KMO8biFQEbXEpVnKAg4fdet1NJxuUAR00kgBEPlPP');
        $cart= $request->get('cart');
        $billing= $request->get('billing');
        if(!count($cart))
            return "Bad request: Cannot checkout an empty cart";

        foreach ($cart as $key => $product) {
            if(!isset($product['id']))
                return "Bad request: one or more cart items does not contain id field";

            if(!isset($product['quantity']))
                return "Bad request: one or more cart items does not contain quantity field";
        }


        $amount = 0;
        $prices = [];
        $checkout = [];
        $orderId = DB::table('orders')->max('id');
        if(empty($orderId) || $orderId == null)
        $orderId = 1;
        else
        $orderId++;

        $billing[0]['orderId'] = $orderId;
        foreach ($cart as $product) {
            $item = [];
            $id =  $product['id'];
            $row = Product::where('id', $id)->get();
            if(count($row) == 0) {
                return Response::json([
                    'status' => false,
                    'error' => "Product with id: $id not found"
                ], 406);            
            }
            $row = $row[0];
            $item['price'] = $row->price;
            $item['quantity'] = $product['quantity'];
            $paymentRequest['line_items'] []= $item;
            $amount = ($row->price * $product['quantity']);

            $products[]= [
                'product_id' => $id,
                'price' => $row->price,
                'quantity' => $product['quantity'],
                'subtotal' => $amount,
                'stripe_test_id' => $row->stripe_test_id
            ];
            
            $order = [
                'order_id' => $orderId,
                'user_id' => Auth::user()->id,
                'card_id' => 0,
                'product_id' =>  $id,
                'quantity' => $product['quantity'],
                'price_unit' => $amount,
                'subtotal_row' => $amount
            ];
            Order::create($order);

            $payload =
                [
                    'currency' => 'eur',
                    'product' => $row->stripe_test_id,
                    'unit_amount' => $product['quantity'],
                ];
                // $stripeProduct = $stripe->prices->create($payload);
                $checkout []= [
                    'price' => $row->stripe_test_id,
                    'quantity' => $product['quantity'],
                ];    
            }
            
            $response = [
                'line_items' =>  $checkout,
                'mode' => 'payment',
                'success_url' => 'https://kendydrink.com/complete',
                'cancel_url' => 'https://kendydrink.com/cancel.html',
            ];

            \Stripe\Stripe::setApiKey("sk_test_51NGgNzGfXypnSGPSkdMqKlzm59UbUjgC7i0KsfIW0YmpuYjEly1EI0mm0KMO8biFQEbXEpVnKAg4fdet1NJxuUAR00kgBEPlPP");
            $checkout_session = \Stripe\Checkout\Session::create($response);

            Billing::create($billing[0]);
            $this->checkoutEmail(Auth::user()->email, $products);
              return json_encode(['url' => $checkout_session->url]);

    } 

    public function test(Request $request) {
        return Auth::user();
    }

    public function getOrderNumber() {
        $order =  DB::table('orders')
        ->select('orders.order_id',DB::raw('ifnull(sum(orders.order_id), 0)'))
        ->groupBy('orders.order_id')
        ->get();
        if(!count($order)) {
            $orderId = 1;
        } else {
            $orderId = $order[0]->order_id;
            $orderId += 1;
        }
        return $orderId;
    }

    public function create($user_id, $card_id, $products) {
        $orderId = $this->getOrderNumber();

        foreach ($products as $product) { 
            $order = new Order();
            $order->order_id = $orderId;
            $order->user_id = $user_id;
            $order->card_id = $card_id;
            $order->product_id = $product['product_id'];
            $order->quantity = $product['quantity'];
            $order->price_unit = $product['price'];
            $order->subtotal_row = $product['subtotal'];
            $order->save();
        }
    }

}
